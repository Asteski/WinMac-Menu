# WinMacMenu Quick Start

- Build presets: x64 and ARM64
- Artifacts: build-x64/Release/WinMacMenu.exe and build-arm64/Release/WinMacMenu.exe

Build:

```pwsh
cmake --preset x64-release
cmake --build --preset x64-release

cmake --preset arm64-release
cmake --build --preset arm64-release
```

Run:

```pwsh
# Default INI next to the EXE
./WinMacMenu.exe

# Custom INI path
./WinMacMenu.exe --config C:\Tools\menu.ini

# Background mode (stays running, Windows key / edge triggers if configured in INI)
./WinMacMenu.exe --config C:\Tools\menu.ini
```

Background mode:

- Enable in `config.ini` under `[General]`:
	- `RunInBackground=true` keeps the app running in the background for instant menu display.
	- `ShowTrayIcon=true` shows an icon in the system tray while running in background. Left-click toggles the menu; right-click shows a small menu with "Show menu" and "Exit".
- When in background mode, clicking outside the menu, pressing the Windows key, or Escape hides the menu (the process keeps running).
- Starting WinMacMenu again while it’s already running in background will simply signal the existing instance to show/toggle the menu and exit immediately.

Start on login:

- In `[General]`, set `StartOnLogin=true` to add a Run entry under HKCU for the current config (value name is unique per-config). The command line preserves your `--config` path.
- Set `StartOnLogin=false` to remove that registry entry cleanly.

Inline Folder Expansion (experimental):
- Add `inline` to the Params field of a FOLDER item to inject its first-level contents directly into the root menu.
- Add `inlineopen` instead of `inline` to make the header (Label) clickable (opens the folder) while still expanding contents inline.
- Add `notitle` (or `noheader`) with `inline` to suppress the grayed header (omit with `inlineopen` if you want the clickable header line).

Examples (in [Menu]):
```
Item5=Code|FOLDER|%USERPROFILE%\Code|inline|
Item6=My Scripts|FOLDER|%USERPROFILE%\Scripts|inline notitle|
Item7=Projects|FOLDER|%USERPROFILE%\Projects|inlineopen|
```

Behavior:
- Direct files appear as normal clickable items.
- Subdirectories appear as expandable lazy submenus (respecting visibility filters and depth limits).
- No automatic separator is added; manage separators explicitly with SEPARATOR items if desired.
- `inlineopen` creates a clickable header line first.

Default Behaviors:
- Folder submenus now use single-click open by default (FolderSubmenuOpen=single). Set `FolderSubmenuOpen=double` in [General] to require a double click.
- ShowDotfiles supports: false | true | filesonly | foldersonly (default false). Extended modes let you selectively expose dot files vs dot folders.

Global Toggle (submenus):
- `[General] FolderShowOpenEntry=false` hides the automatic "Open <folder>" line at the top of folder submenus when single-click mode is enabled.
