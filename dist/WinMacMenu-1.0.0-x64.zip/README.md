# WinMacMenu Handoff README

This repository contains **WinMacMenu**, a Windows context-menu style launcher written in C with a companion WinUI 3 helper. It shows a customizable popup menu that can behave like a lightweight Start menu or shell launcher, with configurable folders, recent items, icons, commands, and power actions.

This README is written as a fast handoff for another Codex instance so it can pick up the project quickly without re-discovering the structure.

## What The App Does

- Displays a Windows-style popup menu
- Reads menu contents from an INI file
- Supports:
  - URIs
  - files
  - shell commands
  - folder submenus
  - `THISPC`
  - `HOME`
  - `RECENT`
  - power actions
  - settings entry
- Adapts to light/dark theme
- Supports per-item icons and theme-specific icon overrides
- Can run in background mode with a tray icon
- Can also build and use a WinUI 3 menu helper

Current version is `1.0.0`.

## Important Project Layout

- [`src/main.c`](src/main.c): app startup, CLI, window creation, tray integration, instance management
- [`src/menu.c`](src/menu.c): menu construction, folder submenus, recent items, special items, icon assignment
- [`src/config.c`](src/config.c): INI parsing, defaults, config loading and saving behavior
- [`src/settings.c`](src/settings.c): settings dialog, footer layout, live updates, button handling
- [`src/custom_theme_dll.c`](src/custom_theme_dll.c): dormant embedded custom-theme backend
- [`src/custom_theme_bridge.c`](src/custom_theme_bridge.c): bridge between the app and the dormant custom-theme backend
- [`winui3/WinMacMenuWinUI3`](winui3/WinMacMenuWinUI3): WinUI 3 helper project
- [`WinMacMenu.rc`](WinMacMenu.rc): resources, dialog templates, icons, version block
- [`res/`](res): embedded icons

## Build System

- Root build is CMake + Visual Studio generator
- Presets:
  - `x64-release`
  - `arm64-release`
- Build output for x64 currently lands in `build-x64/Release/WinMacMenu.exe`

Build commands:

```pwsh
cmake --preset x64-release
cmake --build --preset x64-release
```

If you need ARM64:

```pwsh
cmake --preset arm64-release
cmake --build --preset arm64-release
```

The CMake file also builds the WinUI 3 helper when available and copies its publish output into the build tree.

## Run Commands

```pwsh
.\build-x64\Release\WinMacMenu.exe
.\build-x64\Release\WinMacMenu.exe --config C:\Path\to\config.ini
```

If no config exists next to the EXE, the app creates a default one.

## Configuration Model

The app is INI-driven. The default config is generated from code if missing.

Main sections:

- `[General]`
- `[Placement]`
- `[Menu]`
- `[Icons]`
- `[IconsLight]`
- `[IconsDark]`
- `[RecentItems]`
- `[TaskKill]`
- `[ThisPC]`
- `[Home]`

Key behavior:

- Menu entries are defined as `ItemN=Label|TYPE|...`
- Icons can come from `.ico`, `.dll`, `.exe`, or a Segoe Fluent Icons glyph
- Environment variables expand in labels, paths, params, and icon paths
- Folder items can be submenus or inline-expanded
- `THISPC` and `HOME` are special item types, not just folder items
- Recent items are built dynamically from the user Recent folder

## Current UI Notes

The settings dialog footer is currently tuned so that:

- `Exit` is left-aligned
- `Help` opens the project wiki
- `Apply` and `Cancel` are the same width
- `Save & Close` is wider than `Apply`

If you need to change that footer, edit both:

- [`WinMacMenu.rc`](WinMacMenu.rc)
- [`src/settings.c`](src/settings.c)

The settings window icon now uses the embedded app icon directly, which is important for docks and other shell integrations.

## Custom Theme Backend

There is a dormant embedded backend that was renamed from `big_menu` to `custom_theme`.

Important points:

- It is kept in the repo
- It is not part of the v1.0.0 user-facing feature set
- It is disabled by default
- It has its own bridge/header/DLL source files
- The output DLL name is `WinMacMenuCustomTheme.dll`

Relevant files:

- [`src/custom_theme_dll.c`](src/custom_theme_dll.c)
- [`src/custom_theme_bridge.c`](src/custom_theme_bridge.c)
- [`src/custom_theme_bridge.h`](src/custom_theme_bridge.h)
- [`src/custom_theme_api.h`](src/custom_theme_api.h)

## Special Menu Items

The app has special built-in menu item types that are easy to forget when editing config or rendering logic:

- `THISPC`
- `HOME`
- `RECENT`
- `TASKKILL`
- `POWER_*`
- `SETTINGS`

If something looks wrong in one of those branches, check `src/menu.c` and `src/config.c` together.

## Known Implementation Details

- The settings dialog button row is repositioned at runtime in `WM_SIZE`, not just in the resource template.
- `HOME` and `THISPC` have custom submenu-building code and icon rules.
- `HOME` icon handling recently needed special attention because the first submenu could fall back to a weaker icon path than deeper levels.
- The app can run as background mode with tray integration or as a one-shot popup.
- A separate WinUI 3 helper is still part of the build.

## Good Places To Start When Making Changes

- Menu behavior or special items:
  - [`src/menu.c`](src/menu.c)
- Config format or defaults:
  - [`src/config.c`](src/config.c)
  - [`src/config.h`](src/config.h)
- Settings dialog UI:
  - [`src/settings.c`](src/settings.c)
  - [`WinMacMenu.rc`](WinMacMenu.rc)
- Tray or startup behavior:
  - [`src/main.c`](src/main.c)
- WinUI helper:
  - [`winui3/WinMacMenuWinUI3`](winui3/WinMacMenuWinUI3)

## Repo Hygiene

This repo should stay source-focused. Build outputs and distro packages are intentionally not the main thing to carry around when syncing the project between devices.

If you are preparing this for another machine or for GitHub:

- keep the source tree clean
- avoid committing build artifacts unless you explicitly need them
- make sure the remote is configured before pushing

## Useful Companion Docs

- [`QUICKSTART.md`](QUICKSTART.md)
- [`FEATURES.md`](FEATURES.md)
- [`CLI_USAGE.md`](CLI_USAGE.md)
- [`IMPLEMENTATION_SUMMARY.md`](IMPLEMENTATION_SUMMARY.md)
- [`CUSTOM_THEME_DLL.md`](CUSTOM_THEME_DLL.md)
- [`CUSTOM_THEME_TEST_SCENARIO.md`](CUSTOM_THEME_TEST_SCENARIO.md)

## Notes For The Next Codex Instance

If you are continuing work here, the safest workflow is:

1. Read this README and `QUICKSTART.md`
2. Inspect the specific source file for the feature you want to change
3. Rebuild with the x64 preset
4. If the change affects visuals, inspect the screenshot or run the app and verify the layout

This repo has a lot of special-case menu logic, so changes to one branch can accidentally affect another. The main thing to watch is shared icon and submenu code in `src/menu.c`.
