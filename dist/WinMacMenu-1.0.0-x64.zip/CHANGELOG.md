# Changelog

## 1.0.0 - 2026-08-22

- Bumped application version to 1.0.0.
- Cleaned up settings labels and removed the folder metadata threshold option.

All notable changes to this project will be documented in this file.

The format loosely follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) — versions are not yet formalized, so entries are grouped by date.

## [Unreleased]

## 1.0.0-beta4 - 2026-07-18

- Added custom INI names to the settings window title.
- Added a WinUI option to show file type icons instead of thumbnails in generated submenus.
- Updated the WinUI renderer from Windows App SDK 1.6 to 1.8.260710003.
- Bumped application version to 1.0.0-beta4.

## 1.0.0-beta3 - 2026-07-12

- Bumped application version to 1.0.0-beta3.

## 1.0.0-beta2 - 2026-07-09

- Bumped application version to 1.0.0-beta2.

## 1.0.0-beta - 2026-07-09

- Added WinUI menu style integration.
- Added Win key + X trigger support.
- Bumped application version to 1.0.0-beta.

## 0.15.0 - 2026-07-08

- Added large-menu highlight frame style setting: background, border, or background + border.
- Added Recent Items grouping option to show folders and files separately.
- Bumped application version to 0.15.0.

## 0.14.1 - 2026-03-07
### Changed
- Bumped application version to 0.14.1.

## 0.9.0 - 2025-09-23
### Added
- Consolidated Power Menu item (POWER_MENU) with new inclusion model: only excluded actions are written as `Name=0` under [Power]; absence = included.
- Advanced tab checkboxes now represent inclusion (checked = included). Backward compatibility: legacy `Exclude*` keys still parsed but not written back.
- Hibernate power action support and runtime omission logic via config.
- Settings dialog General tab: button to open the config folder plus clear filename display (single line with italic filename).
- Automatic cleanup of empty sections: removes `[Power]`, `[Icons]`, `[IconsLight]`, `[IconsDark]` if they contain no keys after saving.
- ARM64 build artifacts produced alongside x64.

### Changed
- Inverted power option semantics (Exclude* -> inclusion checkboxes) to reduce double negatives in UI.
- Config filename presentation refined (now single line: `Config file used: <name>.ini`).
- About dialog now uses dedicated `about.ico` resource.
- Default generated config/env token: renamed `%WINMAC_PATH%` to `%WINMAC%` (shorter; old token still functions only if user kept it manually—generated defaults now use the new token).

### Fixed
- Removed prior ShellExecute implicit declaration warning by including headers in correct order.
- Corrected side button width mismatches between Menu and Icons pages for consistent layout.

### Internal
- Refactored settings loading/saving logic for new power inclusion model.
- Added italic runtime font creation for filename label (cleaned up on dialog destroy).
- Section deletion logic centralized using `WritePrivateProfileStringW(section, NULL, NULL, path)` pattern.

### Hashes (for release packaging)
Provided separately in `SHA256SUMS.txt`.

## 0.4.0 - 2025-09-22
### Changed
- Bumped version to 0.4.0.
- Updated system tray light/dark icons with refreshed artwork.
- Explicit Unicode escapes for copyright symbol to avoid stray encoding artifacts.

### Fixed
- Eliminated mojibake issue where a stray 'Â' could appear before the © symbol in the About dialog on some ANSI code pages.

### Internal
- Resource script touch to force icon resource re-embed.

## 2025-09-19
### Added
- Embedded multi-size application icon (`app.ico`) and integrated it for window class and tray.
- DPI-aware tray icon reload on `WM_DPICHANGED` and Explorer restart (`TaskbarCreated`).
- Tray icon reload helper (`tray_reload`) to centralize re-add logic.
- README "Recent Changes" section summarizing modifications.
- ARM64 build verification alongside x64.

### Changed
- Tray icon loading now prefers system small icon metrics and gracefully falls back, improving sharpness.
- Tooltip naming simplified to: `WinMac Menu` (default) or `WinMac Menu (<FileBaseName>)` for non-default INI filenames.
 - Recent items: skip shortcuts whose targets no longer exist (prevents blank entries opening System32).

### Removed / Reverted
- Per-config dynamic HKCU Run value naming (reverted to constant `WinMac Menu` for clarity and to avoid registry clutter).

### Internal / Maintenance
- Refactored startup naming experiment out after evaluation.
- Added defensive icon fallback path (default system icon if resource load fails).

---

> Historical experimental changes that were reverted are documented to provide context for design decisions.
